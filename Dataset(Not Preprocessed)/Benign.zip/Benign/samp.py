import pandas as pd
import glob
import os
import json

adv_path = "."  # Current folder (Adversarial)

# 1. Get all CSV files
csv_files = glob.glob(os.path.join(adv_path, "*.csv"))
df_list = []

if not csv_files:
    print("No CSV files found!")
else:
    for f in csv_files:
        try:
            # Try reading CSV with utf-8 first, fallback to latin1
            try:
                temp_df = pd.read_csv(f)
            except:
                temp_df = pd.read_csv(f, encoding='latin1')
            if temp_df.empty:
                print(f"Skipped empty file: {f}")
                continue
            temp_df['label'] = 'adversarial'
            temp_df['attack_type'] = os.path.basename(f).replace('.csv','')
            df_list.append(temp_df)
            print(f"Loaded {f} with {len(temp_df)} samples")
        except Exception as e:
            print(f"Failed to read {f}: {e}")

# 2. Concatenate CSVs safely
if df_list:
    adv_df = pd.concat(df_list, ignore_index=True)
else:
    adv_df = pd.DataFrame()
    print("No CSVs could be loaded successfully!")

# 3. Read JSONL if exists
jsonl_file = os.path.join(adv_path, "raw_dump_attacks.jsonl")
if os.path.exists(jsonl_file):
    json_list = []
    with open(jsonl_file, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)
                data['label'] = 'adversarial'
                data['attack_type'] = 'jsonl_attack'
                json_list.append(data)
            except:
                continue
    if json_list:
        json_df = pd.DataFrame(json_list)
        if adv_df.empty:
            adv_df = json_df
        else:
            adv_df = pd.concat([adv_df, json_df], ignore_index=True)
        print(f"Loaded {len(json_df)} samples from JSONL")

# 4. Output stats
print("Total adversarial samples:", len(adv_df))
if 'attack_type' in adv_df.columns:
    print("Attack type counts:")
    print(adv_df['attack_type'].value_counts())

# 5. Save combined CSV
if len(adv_df) > 0:
    adv_df.to_csv("combined_adversarial.csv", index=False)
    print("Combined adversarial dataset saved as combined_adversarial.csv")
else:
    print("No data to save!")

